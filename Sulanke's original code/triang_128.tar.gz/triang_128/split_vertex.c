/* split a vertex, v1, along the edges (v1,v2) and (v1,v3) so that v4 (not v2 
   nor v3 but a neighbor of v1 before the split) is a neighbor of the new 
   vertex.  
   if (v1,v2,v3) is a face and v4 is either v2 or v3 then new vertex is inside
   that face */

/*
      before                      after

     v2----v1----v3                     v1
           |                           /| \
           |                          / |  \
           v4                       v2--v---v3
                                        |    
                                        |  
                                        v4
*/

#include <triang.h>

void split_vertex(struct triang *t, int v1, int v2, int v3, int v4)
{
  int v, vn, vprev, o1, o2, v5;

#if DEBUG
  if (v1 < 0 || v1 >= t->nv || 
      v2 < 0 || v2 >= t->nv || 
      v3 < 0 || v3 >= t->nv || 
      v4 < 0 || v4 >= t->nv) {
    printf("split_vertex: vertex (%d, %d, %d or %d) out of range. must be betwee 0 and %.\n",
	   v1,v2,v3,v4,t->nv);
    exit(0);
  }

  if (t->edge[v1][v2] == -1 || t->edge[v1][v3] == -1 || t->edge[v1][v4] == -1) {
    printf("split_vertex: (%d, %d), (%d, %d) or (%d, %d) not an edge .\n",
	   v1,v2,v1,v3,v1,v4);
    exit(0);
  }

  if (t->edge[v1][v2] != v3 && t->edge[v2][v1] != v3) {
    if (v1 == v2 || v1 == v3 || v2 == v3 || v1 == v4 || v2 == v4 || v3 == v4) {
      printf("split_vertex: vertices (%d, %d, %d and %d) must be distinct.\n",
	     v1,v2,v3,v4);
      exit(0);
    }
  }
  else {
    if (v1 == v2 || v1 == v3 || v2 == v3) {
      printf("split_vertex: vertices (%d, %d and %d) must be distinct.\n",
	     v1,v2,v3);
      exit(0);
    }
  }
  
#endif
  
  /* put new vertex in triangle */

  if ((t->edge[v1][v2] == v3 || t->edge[v2][v1] == v3) && 
      (v3 == v4 || v2 == v4))
    v = v3;
  else {
    v = t->edge[v1][v2];
    vprev = v2;
    while (v != v3 && v != v4) {
      v5 = v;
      v = opposite(t,vprev,v1,v5);
      vprev = v5;
    }
    if (v == v4)
      v = t->edge[v1][v2];
    else
      v = t->edge[v2][v1];
  }

  add_vertex(t,v1,v2,v);

  /* vn is new vertex */

  vn = (t->nv)-1;

  while (v != v3) {
    find_flip(t,v1,v,&o1,&o2);
    flip_edge(t,v1,v,o1,o2);
    if (vn == o1)
      v = o2;
    else
      v = o1;
  }

}
