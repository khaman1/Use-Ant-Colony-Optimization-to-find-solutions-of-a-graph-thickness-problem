/* 
   Program to search for T triangulations whose union is the complement of
   a given graph. 
   This version uses recursive search.
*/

#include <triang.h>

#define T 2
#define NV 11

main()
     
{
  struct triang t[T];      /* the T triangulations */
  struct triang c;         /* the complement of their union */
  struct triang g;         /* given graph */
  int nv;                  /* # vertices in given graph */
  int igraph;              /* graph index from input */
  int nmiss;               /* # edges in c not in g */
  int v1,v2,v3,v4,v;
  int nt[MAX_V][MAX_V];    /* # triangulations to which this edge belongs */
  int ran;
  int it;
  int ok;
  int nflips;
  int delta_miss;          /* amount nmiss would change if flip */

  /* read in the given graph */

  read1(&g,&nv,&igraph);
  if (nv != NV) {
    printf("input graph is wrong size (%d) should be %d.\n",nv,NV);
    exit(1);
  }

  printf("given graph\n");
  print_comp(&g,nt);

  nmiss = 1000;
  while (nmiss > 0) {

    /* create the triangulations and the complement */

    for (it=0;it<T;it++) {
      create_triang(&t[it],NV);
      scramble_triang(&t[it]);
      ran_flip_triang(&t[it],500);
    }

    c.nv = NV;
    clear_triang(&c);
    
    nmiss = 0;
    for (v1=0;v1<NV-1;v1++) {
      nt[v1][v1] = 0;
      for (v2=v1+1;v2<NV;v2++) {
	nt[v1][v2] = 0;
	for (it=0;it<T;it++)
	  if (t[it].edge[v1][v2])
	    nt[v1][v2]++;
	nt[v2][v1] = nt[v1][v2];
	if (nt[v1][v2] == 0) {
	  add_edge(&c,v1,v2);
	  if (g.edge[v1][v2] = -1)
	    nmiss++;
	}
      }
    }

    /* repeat until we have found the solution, ha! */
    
    next_flip(&t,&nmiss);
    
    printf("nmiss = %d\n",nmiss);

  }

  /* dump */

  for (it=0;it<T;it++) {
    printf("triangulation %d\n",it);
    print_triang(&t[it]);
  }

  printf("complement\n");
  print_comp(&c,nt);
}
