/* include file to be used in user's programs */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_V 128
#define MAX_E (MAX_V*(MAX_V-1)/2)
#define MAX_F ((MAX_E/3)*2)
#define MAX_CODE (MAX_E+MAX_E+MAX_V+4)

struct triang {      /* triangulation */
  int nv;
  int ne;
  int nf;
  int orient;        /* oriented? (not same as orientable), 
			-1 not yet determined */
  int genus;         /* genus of surface 
			(= number of handles or = number of crosscaps 
			-1 not yet determined */
  int edge[MAX_V][MAX_V];
};

void add_face(struct triang *t, int v1, int v2, int v3);

void canon(struct triang *t, char code[], int mapping[]);

void canonlex(struct triang *t, char *text);

int  can_contract(struct triang *t, int v1, int v2, int *o1, int *o2);
 
int  check_triang(struct triang *t, char *caller);

void clear_triang(struct triang *t, int v);

void contract_edge(struct triang *t, int v1, int v2, int o1, int o2);

void copy_triang(struct triang *s, struct triang *t);

int  count_triang(struct triang *t);

void create_triang(struct triang *t, int v, int genus, int orient);

void create_triang4(struct triang *t, int v, int genus, int orient);

void cut_handle(struct triang *t, int v1, int v2, int v3, int v4);

void cycle_type(struct triang *t, int v[MAX_V], int n, int *type, int genus[2], int orient[2], int nv[2], int ne[2], int nf[2]);

int  decode_triang(char *text, struct triang *t);

int  decode_triang_lex(char *text, struct triang *t);

int  decode_unfold_triang(char *text, struct triang *t, int border[MAX_V][MAX_V]);

void encode_planar_code(struct triang *t, char code[]);

int  find_flip(struct triang *t, int v1, int v2, int *v3, int *v4);

void flip_edge(struct triang *t, int v1, int v2, int v3, int v4);

int near_triang(struct triang *t);

int opposite(struct triang *t, int v1, int v2, int v3);

void permute_triang(struct triang *t, int v1, int v2);

void print_ascii(struct triang *t);

void print_neighbors(struct triang *t);

void print_triang(struct triang *t);

void ran_flip_triang(struct triang *t, int ntimes);

int  read_triang(struct triang *t);

int  read_triang_lex(struct triang *t);

int reduce_triang(struct triang *t, int nv);

int reduce_triang4(struct triang *t, int nv);

void remove_degree3_vertex(struct triang *t, int v);

void remove_face(struct triang *t, int v1, int v2, int v3);

void scramble_triang(struct triang *t);

void split_vertex(struct triang *t, int v1, int v2, int v3, int v4);

void testcanon_first_init_triang(struct triang *t, int givenedge[3], int representation[], int mapping[], int colour[]);

void testcanon_init_triang(struct triang *t, int givenedge[3], int representation[], int mapping[], int colour[]);

void unfold_canon(struct triang *t, int border[MAX_V][MAX_V], int *nv_unfold, char code[], int mapping[]);

void unfold_testcanon_init(struct triang *t, int nv_unfold, int v_border[MAX_V], int r_border[MAX_V], int border_length, int dir, int iborder, int label[MAX_V][MAX_V], int border[MAX_V][MAX_V], int representation[], int mapping[], int colour[]);

void unfold_triang(struct triang *t, int border_length, int v_border[MAX_V], int *nv_unfold, char code[], int mapping[]);

int write_triang_lex(struct triang *t);

static int a2i[128] = {
  -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
  -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
  -1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1,
  -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1};

static char i2a[52] = {
  'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
  'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
