/* pirnt info about a graph */

#include <triang.h>

void print_g(struct triang *t)
{
  int v1,v2;

  if (t->nv < 4 || t->nv > MAX_V)
    {
      printf("print_comp: number of vertices must be at least 4 and less than %d but is %d.\n",MAX_V,t->nv);
      return;
    }

  printf("vertices: %d, edges: %d\n",t->nv,t->ne);

  printf("\n   ");
  for (v2=0;v2<t->nv;v2++)
    printf("%1d",v2/10);
  printf("\n   ");
  for (v2=0;v2<t->nv;v2++)
    printf("%1d",v2%10);
  printf("\n");
  
  for (v1=0;v1<t->nv;v1++) {
    printf("\n%2d ",v1);
    for (v2=0;v2<t->nv;v2++)
      printf("%1d",t->edge[v1][v2]);
  }
  printf("\n\n");

}




