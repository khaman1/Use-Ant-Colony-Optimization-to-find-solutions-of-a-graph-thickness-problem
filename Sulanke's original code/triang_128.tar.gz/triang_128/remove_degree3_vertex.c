/* remove one vertex of degree 3 from a triangulation */

#include <triang.h>

void remove_degree3_vertex(struct triang *t, int v)
{
  int v1,v2,v3,v4;

  permute_triang(t,v,t->nv-1);
  v1 = t->nv-1;
  v2 = 0;
  while (t->edge[v1][v2]==-1)
    v2++;
  v3 = t->edge[v1][v2];
  v4 = t->edge[v2][v1];

#if DEBUG
  if (t->edge[v3][v4]!=v1 && t->edge[v4][v3]!=v1) {
    printf("remove_degree3_vertex: degree not 3 or other problem removing %d.\nv2,v3,v4 = %d,%d,%d\n",v,v2,v3,v4);
    exit(0);
  }
#endif

  remove_face(t,v1,v2,v3);
  remove_face(t,v1,v3,v4);
  remove_face(t,v1,v4,v2);
  add_face(t,v2,v3,v4);
  (t->nv)--;
  t->ne = t->ne - 3;
}
