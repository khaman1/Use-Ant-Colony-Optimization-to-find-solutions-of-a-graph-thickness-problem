
#include <triang.h>

#define TRUE 1
#define FALSE 0

void smaller_lex(struct triang *t, int list[MAX_F][3], int better, int iface, 
		int pre_label[], int next_label)
{
  /* check if the relabeling starting at iface is lexicographically 
     smaller than the current labeling. if it is relabeling become the new 
     current labeling */
  
  /*
    better is FALSE if the best known labeling is given by the labels in list.
    better is TRUE if 
    the begining of the best known labeling is provided by pre_label.
    list is a list of the ordered labels for faces in lexicographic 
    order.  If better is FALSE then list is defined for all faces, otherwise,
    only for the first iface faces.
    iface is the face index for start of checking.
    pre_label[i] is the label that have already been assigned for the 
    relabeling to vertex i or -1 if a label has not yet been assigned.
    next_label is the next unused label.
  */

  int v;
  int label[3];         /* labels in the relabeling which might be assigned 
			   to the next face */
  int v_to_label[MAX_V]; /* relabeling of vertices */
  int label_to_v[MAX_V]; /* vertex with label in relabeling */
  int w0,w1,w2;         /* vertices of face relabeled 
			   (label[0],label[1],label[2]) */
  int i;                /* vertex index for face */
  int branch;           /* search might branch */
  
  for (v=0; v<t->nv; v++) {
    v_to_label[v] = pre_label[v];
    if (pre_label[v] != -1)
      label_to_v[pre_label[v]] = v;
  }
  
  branch = FALSE;
  
  for (i=0; i<3; i++)
    label[i] = list[iface-1][i];
  label[2]++;
  
  while (iface<t->nf) {
    
    /* label[0], label[1], and label[2] are labels in the relabeling which 
       might be assigned to the next face*/
    /* find the next relabeled face */
    
    w2 = -1;
    while (w2 == -1) {
      
      /* check if there is a face which can be relabeled 
	 (label[0],label[1],label[2]) */

      w0 = label_to_v[label[0]];
      w1 = label_to_v[label[1]];
      
      if (t->edge[w0][w1] != -1 &&
	  t->edge[w1][w0] != -1) {

	/* there are two faces which have two vertices relabeled 
	   label[0] and label[1].
	   check if either third vertex has already been labeled and has not
	   already been used with w0 and w1. */

	if (v_to_label[t->edge[w0][w1]] >= label[2] &&
	    v_to_label[t->edge[w1][w0]] >= label[2]) {

	  /* both third vertex have already been labeled and have not
	     already been used with w0 and w1.
	     pick the one with the smaller label. */

	  if (v_to_label[t->edge[w0][w1]] > v_to_label[t->edge[w1][w0]])
	    w2 = t->edge[w1][w0];
	  else
	    w2 = t->edge[w0][w1];
	}
	else if (v_to_label[t->edge[w0][w1]] >= label[2])

	  /* one third vertex has already been labeled and has not
	     already been used with w0 and w1.  pick it. */

	  w2 = t->edge[w0][w1];
	else if (v_to_label[t->edge[w1][w0]] >= label[2])

	  /* the other third vertex has already been labeled and has not
	     already been used with w0 and w1.  pick it. */

	  w2 = t->edge[w1][w0];

	/* neither third vertex has already been labeled and has not
	   already been used with w0 and w1.
	   check if either or both are available for relabeling. */

	else if (v_to_label[t->edge[w0][w1]] == -1) {
	  
	  /* first 3rd vertices of the faces of (w0,w1) is unlabeled. */

	  if (v_to_label[t->edge[w1][w0]] == -1)
	    
	    /* both 3rd vertices of the faces of (w0,w1) are unlabeled.  
	       the search must branch below */
	    
	    branch = TRUE;
	  
	  /* use first */

	  w2 = t->edge[w0][w1];
	  v_to_label[w2] = next_label;
	  label_to_v[next_label] = w2;
	  next_label++;
	}
	else if (v_to_label[t->edge[w1][w0]] == -1) {

	  /* only second 3rd vertices of the faces of (w0,w1) is unlabeled. 
	     use second. */

	  w2 = t->edge[w1][w0];
	  v_to_label[w2] = next_label;
	  label_to_v[next_label] = w2;
	  next_label++;
	}
      }
      else if (t->edge[w0][w1] != -1) {

	/* there is only one face which have two vertices relabeled 
	   label[0] and label[1]. */
	
	if (v_to_label[t->edge[w0][w1]] >= label[2])

	  /* third vertex has already been labeled and has not
	     already been used with w0 and w1.  use it. */

	  w2 = t->edge[w0][w1];
	else if (v_to_label[t->edge[w0][w1]] == -1) {

	  /* third vertex has not been labeled.  use it. */

	  w2 = t->edge[w0][w1];
	  v_to_label[w2] = next_label;
	  label_to_v[next_label] = w2;
	  next_label++;
	}
      }
      else if (t->edge[w1][w0] != -1) {
	
	/* same as above */
	
	if (v_to_label[t->edge[w1][w0]] >= label[2])
	  w2 = t->edge[w1][w0];
	else if (v_to_label[t->edge[w1][w0]] == -1) {
	  w2 = t->edge[w1][w0];
	  v_to_label[w2] = next_label;
	  label_to_v[next_label] = w2;
	  next_label++;
	}
      }
      
      if (w2 == -1) {

	/* no third vertex was found which shares a face with w0 and w1 and 
	   is or could be labeled label[2] or higher */

	if (!better && 
	    (label[0] == list[iface][0] && label[1] == list[iface][1]))
	  
	  /* current labeling is still best known and 
	     current labeling has another face with (label[0],label[1]) but
	     relabeling does not. */
	  
	  return;
	else {
	  
	  /* relabeling is better or
	     neither current labeling nor relabeling have another face with 
	     (label[0],label[1]). */
	  
	  label[1]++;
	  if (label[1] == next_label ||
	      label[1] == t->nv-1) {
	    label[0]++;
	    label[1] = label[0] + 1;
	  }
	  label[2] = label[1] + 1;
	}
      }
      else {

	/* there is a third vertex which shares a face with w0 and w1 and 
	   is or could be labeled label[2] or higher */

	if (!better && 
	    (label[0] == list[iface][0] && label[1] == list[iface][1])) {

	  /* current labeling is still best known and 
	     current labeling and relabeling both have another face with 
	     (label[0],label[1]). */
	  
	  if (v_to_label[w2] > list[iface][2])
	     
	    /* current labeling is smaller. */
	    
	    return;
	  else if (v_to_label[w2] < list[iface][2]) {
	    
	    /* relabeling is smaller. */
	    
	    better = TRUE;
	    list[iface][2] = v_to_label[w2];
	  }

	  /* current labeling and relabeling both have another face with 
	     (label[0],label[1]).  they are the same. */
	  
	  label[2] = list[iface][2] + 1;
	}
	else {
	  
	  /* relabeling is better or 
	     current labeling does not have another face with 
	     (label[0],label[1]) but relabeling does. */
	  
	  list[iface][0] = label[0] = v_to_label[w0];
	  list[iface][1] = label[1] = v_to_label[w1];
	  list[iface][2] = v_to_label[w2];
	  label[2] = list[iface][2] + 1;
	  better = TRUE;
	}
	
	if (branch) {

	  /* both 3rd vertices of the faces of (w0,w1) are unlabeled.  
	     check one recursively. */
	    
	  smaller_lex(t,list,better,iface+1,v_to_label,next_label);
	  better = FALSE;
	  branch = FALSE;
	  next_label--;
	  v_to_label[w2] = -1;
	  w2 = t->edge[w1][w0];
	  v_to_label[w2] = next_label;
	  label_to_v[next_label] = w2;
	  next_label++;
	}
      }
    }
    iface++;
  }
  
  /* they are the same */
  
  return;
}

void canonlex(struct triang *t, char *text)
{

  /* find labeling of faces which is lexigraphical minimum */

  int v0,v1,v;
  int ineighbor,ioffset,save;
  int neighbor[MAX_V];
  int mindegree;         /* minimum value of degree.  
			    starting edge must have this degree */
  int first_label[MAX_V]; /* labeling before call to smaller_lex */
  int list[MAX_F][3];    /* list of the vertices in each ordered 
			      face */
  int better;            /* relabeling is better than current */
  int face,iv,ic;
  int degree[MAX_V];

  for (v0=0; v0<t->nv; v0++)
    first_label[v0] = -1;

  for (v0=0; v0<t->nv; v0++)
    degree[v0] = 0;
  for (v0=0; v0<t->nv-1; v0++)
    for (v1=v0+1; v1<t->nv; v1++)
      if (t->edge[v0][v1] != -1) {
	degree[v0]++;
	degree[v1]++;
      }

  mindegree = MAX_V;
  for (v0=0; v0<t->nv; v0++)
    if (degree[v0] < mindegree)
      mindegree = degree[v0];

  /* set first part of list */

  list[0][0] = 0;
  list[0][1] = 1;
  list[0][2] = 2;
  for (ineighbor=1; ineighbor<mindegree-1; ineighbor++) {
    list[ineighbor][0] = 0;
    list[ineighbor][1] = ineighbor;
    list[ineighbor][2] = ineighbor+2;
  }
  list[mindegree-1][0] = 0;
  list[mindegree-1][1] = mindegree-1;
  list[mindegree-1][2] = mindegree;
  
  better = TRUE;
  for (v0=0; v0<t->nv; v0++)
    if (degree[v0] == mindegree) {
      
      /* make a list of the neighbors of v0 */
      
      for (v=0; t->edge[v0][v] == -1; v++) {}
      neighbor[0] = v;
      neighbor[1] = t->edge[v0][v];
      for (ineighbor=2; ineighbor<mindegree; ineighbor++)
	  if (t->edge[v0][neighbor[ineighbor-1]] == neighbor[ineighbor-2])
	    neighbor[ineighbor] = 
	      t->edge[neighbor[ineighbor-1]][v0];
	  else
	    neighbor[ineighbor] = 
	      t->edge[v0][neighbor[ineighbor-1]];
      
      /* set the initial values of first_label for v0 */
      
      first_label[v0] = 0;
      first_label[v] = 1;
      for (ioffset=1; ioffset<=mindegree/2; ioffset++)
	first_label[neighbor[ioffset]] = 2*ioffset;
      for (ioffset=1; ioffset<(mindegree+1)/2; ioffset++)
	first_label[neighbor[-ioffset+mindegree]] = 2*ioffset+1;
      
      for (ineighbor=0; ineighbor<mindegree; ineighbor++) {
	
	/* check starting at each neighbor of v0 going clockwise */
	
	smaller_lex(t,list,better,mindegree,first_label,mindegree+1);
	better = FALSE;

	/* rotate the labeling for next neighbor */
	
	save = first_label[neighbor[mindegree-1]];
	for (ioffset=mindegree-1; ioffset>0; ioffset--)
	  first_label[neighbor[ioffset]] = first_label[neighbor[ioffset-1]];
	first_label[neighbor[0]] = save;
      }
      
      /* flip the labeling for counterclockwise check */
      
      for (ioffset=1; ioffset<(mindegree+1)/2; ioffset++) {
	save = first_label[neighbor[ioffset]];
	first_label[neighbor[ioffset]] = 
	  first_label[neighbor[-ioffset+mindegree]];
	first_label[neighbor[-ioffset+mindegree]] = save;
      }
      
      for (ineighbor=0; ineighbor<mindegree; ineighbor++) {
	
	/* check starting at each neighbor of v0 going counterclockwise */
	
	smaller_lex(t,list,better,mindegree,first_label,mindegree+1);
	better = FALSE;
	
	/* rotate the labeling for next neighbor */
	
	save = first_label[neighbor[mindegree-1]];
	for (ioffset=mindegree-1; ioffset>0; ioffset--)
	  first_label[neighbor[ioffset]] = first_label[neighbor[ioffset-1]];
	first_label[neighbor[0]] = save;
      }
      
      /* undo labeling before next v0) or returning */
      
      first_label[v0] = -1;
      for (ioffset=0; ioffset<mindegree; ioffset++)
	first_label[neighbor[ioffset]] = -1;
    }
  
  /* fill in canonical text */
  
  ic = 0;
  for (face=0; face<t->nf; face++) 
    for (iv=0; iv<3; iv++)
      text[ic++] = i2a[list[face][iv]];
  
  text[ic] = '\0';

}
