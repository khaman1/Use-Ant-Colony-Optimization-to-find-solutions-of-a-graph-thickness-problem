/* contract an edge */

#include <triang.h>

void contract_edge(struct triang *t, int v1, int v2, int o1, int o2)
{
  int v,v3,v4;

  if (t->orient == 1) 
    {
      remove_face(t,v1,v2,o1);
      remove_face(t,v1,o2,v2);
      v3 = o1;
      while (v3 != o2)
	{
	  v4 = t->edge[v3][v2];
	  remove_face(t,v3,v2,v4);
	  add_face(t,v3,v1,v4);
	  v3 = v4;
	}
    }
  else 
    {
      remove_face(t,v1,v2,o1);
      remove_face(t,v1,o2,v2);
      v3 = o1;
      while (v3 != o2)
	{
	  if (t->edge[v2][v3] == -1)
	    v4 = t->edge[v3][v2];
	  else
	    v4 = t->edge[v2][v3];
	  remove_face(t,v3,v2,v4);
	  add_face(t,v3,v1,v4);
	  v3 = v4;
	}
    }
  
  permute_triang(t,v2,t->nv-1);
  (t->nv)--;
  t->ne -= 3;
}
