/* program to test triangulation routines. */

#include <triang.h>

main()
     
{
  struct triang t;
  int test;
  int v,v1,v2,v3,v4,i;
  int genus,orient;
  char code[MAX_V*MAX_V];
  int mapping[MAX_V];
  int border[MAX_V][MAX_V];
  int nv_unfold;

  while ( 1 )
    {

      printf(" 1: Create triangulation\n");
      printf(" 2: Print triangulation\n");
      printf(" 3: Flip edge\n");
      printf(" 4: Permute pair of vertices in triangulation\n");
      printf(" 5: Scramble vertices in triangulation\n");
      printf(" 6: Contract an edge\n");
      printf(" 7: Read triangulation from input\n");
      printf(" 8: Check triangulation\n");
      printf(" 9: Find canonical representation\n");
      printf("10: Add a vertex\n");
      printf("11: Split a vertex\n");
      printf("12: Find unfolded canonical representation\n");
      printf("13: Read triangulation from input in lex format\n");
      printf("14: Write triangulation in lex format\n");
      printf("15: Write triangulation in canonical lex format\n");
      printf("16: Cut a handle\n");
      printf("17: Print paramenters of the triangulation\n");
      printf("18: Check for near triangulation\n");
      printf(" 0: Exit\n");

      get_int("test number",&test);
      
      switch ( test ) {
	
      case 0: {
	exit(1);
      }

      case 1: {
	get_int("Number of vertices",&v);  
	get_int("Surface is orientable? (0/1)",&orient);  
	get_int("Genus of surface (number of handles or crosscaps",&genus);
	create_triang(&t,v,genus,orient);
	break;
      }
      
      case 2: {
	printf("****** output from print_triang:\n\n");
	print_triang(&t);
	printf("****** output from print_neighbors:\n\n");
	print_neighbors(&t);
	printf("****** output from print_ascii:\n\n");
	print_ascii(&t);
	break;
      }
      
      case 3: {
	printf("Flippable edges:\n");
	for (v1=0;v1<t.nv-1;v1++)
	  for (v2=v1+1;v2<t.nv;v2++)
	    if (find_flip(&t,v1,v2,&v3,&v4))
	      printf("(%c,%c)\n",i2a[v1],i2a[v2]);
	get_int("First vertex",&v1);  
	get_int("Second vertex",&v2);
	if (t.edge[v1][v2] == -1)
	  printf("no such edge\n");
	else {
	  if (!find_flip(&t,v1,v2,&v3,&v4))
	    printf("can't flip this edge\n");
	  else
	    flip_edge(&t,v1,v2,v3,v4);
	}
	break;
      }
      
      case 4: {
	get_int("First vertex",&v1);  
	get_int("Second vertex",&v2);
	if (v1==v2 || v1<0 || v1>=t.nv || v2<0 || v2>=t.nv)
	  printf("invalid vertices for permute\n");
	else
	  permute_triang(&t,v1,v2);
	break;
      }
      
      case 5: {
	scramble_triang(&t);
	break;
      }
      
      case 6: {
	printf("possible contractible edges:\n");
	for (v1=0; v1<t.nv-1; v1++)
	  for (v2=v1+1; v2<t.nv; v2++)
	    if (t.edge[v1][v2] != -1)
	      if (can_contract(&t,v1,v2,&v3,&v4))
		printf("%d %d  (%c,%c)\n",v1,v2,i2a[v1],i2a[v2]);
	
	get_int("First vertex",&v1);  
	get_int("Second vertex",&v2);
	if (v1==v2 || v1<0 || v1>=t.nv || v2<0 || v2>=t.nv)
	  printf("invalid vertices for contraction\n");
	else
	  if (t.edge[v1][v2] == -1)
	    printf("no such edge\n");
	  else 
	    if (!can_contract(&t,v1,v2,&v3,&v4))
	      printf("can't contract edge\n");
	    else
	      contract_edge(&t,v1,v2,v3,v4);
	break;
      }
      
      
      case 7: {
	read_triang(&t);
	break;
      }

      case 8: {
	check_triang(&t,"triang_test");
	break;
      }
	
      case 9: {
	canon(&t,code,mapping);
	printf("%s\n",code);
	printf("mapping:");
	for (v1=0;v1<t.nv;v1++)
	  printf(" %d",mapping[v1]);
	printf("\n");
	break;
      }
	
      case 10: {
	get_int("First vertex",&v1);  
	get_int("Second vertex",&v2);
	get_int("Third vertex",&v3);
	if (v1==v2 || v2==v3 || v1==v3 || 
	    v1<0 || v1>=t.nv || v2<0 || v2>=t.nv || v3<0 || v3>=t.nv)
	  printf("invalid vertices for adding vertex.\n");
	else if (t.edge[v1][v2] != v3 && t.edge[v2][v1] != v3)
	  printf("not a face for adding vertex.\n");
	else
	  add_vertex(&t,v1,v2,v3);
	break;
      }
	
      case 11: {
	get_int("Vertex to split",&v1);  
	get_int("Vertex at end of first split edge",&v2);
	get_int("Vertex at end of second split edge",&v3);
	get_int("Vertex to split toward",&v4);
	if (v1==v2 || v2==v3 || v1==v3 || v1==v4 || 
	    v1<0 || v1>=t.nv || v2<0 || v2>=t.nv || v3<0 || v3>=t.nv || v3<0 || v3>=t.nv)
	  printf("invalid vertices for adding vertex.\n");
	else if (t.edge[v1][v2] == -1 || t.edge[v1][v3] == -1 || t.edge[v1][v4] == -1)
	  printf("split edge do not exist.\n");
	else
	  split_vertex(&t,v1,v2,v3,v4);
	break;
      }
	
      case 12: {
	for (v1=0;v1<t.nv;v1++)
	  for (v2=0;v2<t.nv;v2++)
	    border[v1][v2] = 0;
	/*
	v1 = 0;
	v2 = 1;
	while (v1 != v2) {
	  get_int("First vertex of border edge",&v1);  
	  get_int("Second vertex of border edge (same as first to end)",&v2);  
	  if (v1!=v2) {
	    if (v1<0 || v1>=t.nv || v2<0 || v2>=t.nv)
	      printf("invalid pair of vertices for border.\n");
	    else if (t.edge[v1][v2] == -1)
	      printf("edge does not exist.\n");
	    else
	      border[v1][v2] = border[v2][v1] = 1;
	  }
	}
	*/
	border[0][1] = 1;
	border[1][0] = 1;
	border[1][4] = 1;
	border[4][1] = 1;
	border[4][0] = 1;
	border[0][4] = 1;
	unfold_canon(&t,border,&nv_unfold,code,mapping);
	printf("%s\n",code);
	printf("mapping:");
	for (v1=0;v1<nv_unfold;v1++)
	  printf(" %d",mapping[v1]);
	printf("\n");
	decode_unfold_triang(code,&t,border);
	printf("border edges: ");
	for (v1=0;v1<t.nv-1;v1++)
	  for (v2=v1+1;v2<t.nv;v2++)
	    if (border[v1][v2])
	      printf("(%d,%d) ",v1,v2);
	printf("\n");
	break;
      }
      
      case 13: {
	read_triang_lex(&t);
	break;
      }

      case 14: {
	write_triang_lex(&t);
	break;
      }

      case 15: {
	canonlex(&t,code);
	printf("%s\n",code);
	break;
      }

      case 16: {
	get_int("First vertex on cut",&v1);  
	get_int("Secod vertex on cut",&v2);
	get_int("Third vertex on cut",&v3);
	get_int("Vertex to cut toward",&v4);

	cut_handle(&t,v1,v2,v3,v4);
	break;
      }
	
      case 17: {
	printf("nv = %d, ne = %d, nf = %d, orient = %d, genus = %d, X = %d.\n",
	       t.nv,t.ne,t.nf,t.orient,t.genus,t.orient?2-2*t.genus:2-t.genus);
	break;
      }

      case 18: {
	near_triang(&t);
	break;
      }
	
      default: {
	printf("unknown or unimplemented test number (%d)\n",test);
      }
      }
    }
}
