/* read one graph from stdin it should have v vertices */

#include <stdio.h>
#include <triang.h>

void read1(struct triang *t, int *n, int *igraph)
{
  int i,ii,v;
  int ne,e[20];
  char text[80];
  
  /* read the header, get the graph index and its order */
  /* return n=0 if eof */

  if (fgets(text,80,stdin) == NULL) {
    *n = 0;
    return;
  }

  /*
  printf("%s",text);
  */

  fgets(text,80,stdin);

  /*
  printf("%s",text);
  */

  sscanf(text,"Graph %d, order %d.",igraph,n);
  /*
  printf("igraph = %d, n = %d\n",*igraph,*n);
  */

  /* create empty graph with order n */

  t->nv = *n;
  clear_triang(t);

  for (v=0;v<*n;v++) {
    fgets(text,80,stdin);

    /*
    printf("%s",text);
    */

    ne = sscanf(text,
		"%d : %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",
		&ii,&e[0],&e[1],&e[2],&e[3],&e[4],&e[5],&e[6],&e[7],&e[8],&e[9],
		&e[10],&e[11],&e[12],
		&e[13],&e[14],&e[15],&e[16],&e[17],&e[18]);
    if (v != ii)
      printf("read1: wrong vertex number %d should be %d\n",ii,v);
    for (i=0;i<ne-1;i++)
      if (e[i]>v)
	add_edge(t,v,e[i]);
  }

}
