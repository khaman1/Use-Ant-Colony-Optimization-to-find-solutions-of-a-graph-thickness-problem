/* output a triangulation in lex format (not necessarily minimum (canonical)) */

#include <stdio.h>
#include <triang.h>
#define LINELEN 2000

int write_triang_lex(struct triang *t)
{
  char text[LINELEN];
  int ichar;
  int v0,v1;

  for (v0=0; v0<t->nv-2; v0++)
    for (v1=v0+1; v1<t->nv-1; v1++)
      if (t->edge[v0][v1] != -1)
	if (t->edge[v0][v1] < t->edge[v1][v0]) {
	  if (t->edge[v0][v1] > v1)
	    printf("%c%c%c",i2a[v0],i2a[v1],i2a[t->edge[v0][v1]]);
	  if (t->edge[v1][v0] > v1)
	    printf("%c%c%c",i2a[v0],i2a[v1],i2a[t->edge[v1][v0]]);
	}
	else {
	  if (t->edge[v1][v0] > v1)
	    printf("%c%c%c",i2a[v0],i2a[v1],i2a[t->edge[v1][v0]]);
	  if (t->edge[v0][v1] > v1)
	    printf("%c%c%c",i2a[v0],i2a[v1],i2a[t->edge[v0][v1]]);
	}
  printf("\n");
}
