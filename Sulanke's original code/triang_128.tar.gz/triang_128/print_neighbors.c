/* print the order neighbors of a triangulation */

#include <triang.h>

void print_neighbors(struct triang *t)
{
  int v1,v2;
  int first,prev,next;
  int center[MAX_V],order[MAX_V],iprint[MAX_V];
  int norder,nprint;

#if DEBUG
  if (t->nv < 4 || t->nv > MAX_V)
    {
      printf("print_neighbors: number of vertices must be at least 4 and less than %d but is %d.\n",MAX_V,t->nv);
      exit(0);
    }
#endif

  for (v1=0;v1<t->nv;v1++) {
    printf("%d:",v1);
    for (v2 = 0; (v2 == v1 || t->edge[v1][v2] == -1) && v2 < t->nv; v2++) {}
    if (v2 != t->nv) {
      first = v2;
      next = t->edge[v1][v2];
      printf(" %d",v2);
      while (next != first) {
	prev = v2;
	v2 = next;
	printf(" %d",v2);
	if (t->edge[v1][v2] != prev)
	  next = t->edge[v1][v2];
	else
	  next = t->edge[v2][v1];
      }
    }
    printf("\n");
  }

  /*
  printf("\ncode for brute_switch\n");
  for (v1=0;v1<t->nv;v1++) center[v1] = -1;
  v1 = 0;
  for (v2 = 0; v2 == v1 || t->edge[v1][v2] == -1; v2++) {}

  norder = 0;
  center[v2] = v1;
  order[v1] = norder;
  iprint[norder++] = v1;
  center[v1] = v2;
  order[v2] = norder;
  iprint[norder++] = v2;
  
  nprint = 0;
  while (nprint < t->nv)
    {
      v1 = iprint[nprint];
      v2 = center[v1];
      first = v2;
      next = t->edge[v1][v2];
      while (next != first) {
	prev = v2;
	v2 = next;
	if (center[v2] == -1)
	  {
	    center[v2] = v1;
	    order[v2] = norder;
	    iprint[norder++] = v2;
	  }
	printf(" %d",order[v2]+1);
	if (t->edge[v1][v2] != prev)
	  next = t->edge[v1][v2];
	else
	  next = t->edge[v2][v1];
      }
      printf(" 0");
      nprint++;
    }
  printf("\n");
  */
}
