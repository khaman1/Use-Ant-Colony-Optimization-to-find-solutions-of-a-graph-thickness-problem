/* cut_handle.c */

/* cut a handle along the 3-cycle (v1,v2,v3) so that v4 (not v2 
   nor v3 but a neighbor of v1 before the split) is a neighbor of one of 
   the new vertices.  if nv is the number of vertices before the cut then the
   new vertex nv comes from v1, nv+1 from v2 and nv+2 from v3. */

/*
      before                      after

   --v2----v1----v3--                   v1
           |                           /  \
           |                          /    \
           v4                       v2------v3

                                 (nv+1)---(nv+2)
                                     \    /
                                      \  /
                                       nv
                                        |    
                                        |  
                                        v4
*/

#include <triang.h>

void cut_handle(struct triang *t, int v1, int v2, int v3, int v4)
{
  int nv;

#if DEBUG
  if (v1 < 0 || v1 >= t->nv || 
      v2 < 0 || v2 >= t->nv || 
      v3 < 0 || v3 >= t->nv || 
      v4 < 0 || v4 >= t->nv) {
    printf("cut_handle: vertex (%d, %d, %d or %d) out of range. must be betwee 0 and %.\n",

	   v1,v2,v3,v4,t->nv);
    exit(0);
  }

  if (t->edge[v1][v2] == -1 || t->edge[v1][v3] == -1 || 
      t->edge[v2][v3] == -1 || t->edge[v1][v4] == -1) {
    printf("cut_handle: (%d, %d), (%d, %d) or (%d, %d) not an edge .\n",
	   v1,v2,v1,v3,v2,v3,v1,v4);
    exit(0);
  }

  if (t->edge[v1][v2] == v3 || t->edge[v2][v1] == v3) {
    printf("cut_handle: (%d, %d, %d) is a face .\n",
	   v1,v2,v3);
    exit(0);
  }

  if (v1 == v2 || v1 == v3 || v2 == v3 || v1 == v4 || v2 == v4 || v3 == v4) {
    printf("cut_handle: vertices (%d, %d, %d and %d) must be distinct.\n",
	   v1,v2,v3,v4);
    exit(0);
  }
  
#endif
  
  nv = t->nv;
  split_vertex(t,v1,v2,v3,v4);
  split_vertex(t,v2,v1,v3,nv);
  split_vertex(t,v3,v1,v2,nv);

  remove_face(t,v1,nv,t->edge[v1][nv]);
  remove_face(t,nv,v1,t->edge[nv][v1]);
  remove_face(t,v2,nv+1,t->edge[v2][nv+1]);
  remove_face(t,nv+1,v2,t->edge[nv+1][v2]);
  remove_face(t,v3,nv+2,t->edge[v3][nv+2]);
  remove_face(t,nv+2,v3,t->edge[nv+2][v3]);

  if (t->edge[v1][v2] == -1)
    add_face(t,v1,v2,v3);
  else
    add_face(t,v1,v3,v2);
  if (t->edge[nv][nv+1] == -1)
    add_face(t,nv,nv+1,nv+2);
  else
    add_face(t,nv,nv+2,nv+1);

  t->ne -= 6;

  if (t->orient == 1)
    t->genus -= 1;
  else {
    t->genus = -1;
    t->orient = -1;
  }
}
