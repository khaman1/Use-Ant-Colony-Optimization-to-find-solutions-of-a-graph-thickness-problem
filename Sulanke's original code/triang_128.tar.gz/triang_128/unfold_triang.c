/* unfold a triangulaton */

#include <stdio.h>
#include <triang.h>

void unfold_triang(struct triang *t, int border_length, int v_border[MAX_V], 
		   int *nv_unfold, char code[], int mapping[])
{
/* 
   t is the input triangulation, border_length is the number of vertices on 
   the border, v_border is an array of vertices as we go around the border.
   u is the unfolded triangulation, vertex 0 is outside the unfolded 
   triangulation, vertex 1 is v_border[0], etc.
   mapping[i] is the vertex in t corresponding to the i-th vertex of u.
*/

  int v1, v2, v3, v4;
  int colour[MAX_V];    /* 2 * MAX_V */
  int representation[MAX_V*MAX_V];
  int i, icode, inew, irep;
  int first[MAX_V];
  int border_count[MAX_V]; /* number of times vertex appears on border */
  int dups;                /* number of duplicate vertices on border */
  int r_border[MAX_V];     /* r_border[i] is the third vertex of the face to 
			      the right of (v_border[i],v_border[i+1]) */
  int border1, border2;    /* any edge on border */
  int iborder;             /* border vertex index */
  int label[MAX_V][MAX_V]; /* label[i][j] = border index assigned to vertex 
                              i for edge between i and j */
  int border[MAX_V][MAX_V];
  int ok;

  /* count number of times a vertex occurs on the border */
  
  for (v1=0; v1<t->nv; v1++) {
    colour[v1] = 2 * MAX_V;
    border_count[v1] = 0;
    for (v2 = 0; v2 < t->nv; v2++) {
      label[v1][v2] = -1;
      border[v1][v2] = 0;
    }
  }
  border1 = v_border[0];
  border2 = v_border[1];
  dups = 0;
  for (iborder=0; iborder<border_length; iborder++) {
    v1 = v_border[iborder];
    v2 = v_border[(iborder+1)%border_length];
    border_count[v1]++;
    border[v1][v2] = border[v2][v1] = 1;
  }

  for (v1=0; v1<t->nv; v1++) {
    if (border_count[v1] > 0)
      dups = dups + border_count[v1] - 1;
  }

  if (dups == 0)
    *nv_unfold = t->nv;
  else
    *nv_unfold = t->nv + dups + 1;
  

  /* go around the border */

  v1 = border1;
  v2 = border2;
  v3 = t->edge[v1][v2];

  ok = 1;
  for (iborder=0; iborder<border_length && ok; iborder++) {
    ok = v_border[iborder] == v1;
    r_border[iborder] = v3;

    while (!border[v2][v3]) {
      label[v2][v3] = (iborder+1)%border_length;
      v4 = v1;
      v1 = v3;
      v3 = opposite(t,v4,v2,v1);
    }
    v4 = v3;
    v3 = v1;
    v1 = v2;
    v2 = v4;
  }

  if (!ok) {
    v1 = border1;
    v2 = border2;
    v3 = t->edge[v2][v1];

    ok = 1;
    for (iborder=0; iborder<border_length && ok; iborder++) {
      ok = v_border[iborder] == v1;
      r_border[iborder] = v3;
      
      while (!border[v2][v3]) {
	label[v2][v3] = (iborder+1)%border_length;
	v4 = v1;
	v1 = v3;
	v3 = opposite(t,v4,v2,v1);
      }
      v4 = v3;
      v3 = v1;
      v1 = v2;
      v2 = v4;
    }
  }

  if (!ok) {
    fprintf(stderr,"unfold_triang:problems with v_border\n");
    exit(1);
  }

  /* set representation so that first call will be considered an improvement */
  
  representation[0] = MAX_V + MAX_V;
  unfold_testcanon_init(t, *nv_unfold, v_border, r_border, border_length,
			+1, 0,
			label, border, representation, mapping, colour);

  ok = 1;
  for (iborder=0; iborder<border_length && ok; iborder++)
    ok = mapping[iborder+1] == v_border[iborder];

  if (!ok) {
    fprintf(stderr,"unfold_triang: mapping doesn't match v_border\n");
    exit(1);
  }

  /* create code */
  
  if (*nv_unfold >= 10) 
    {
      code[0] = ((*nv_unfold) / 10) + '0';
      code[1] = ((*nv_unfold) % 10) + '0';
      icode = 2;
    }
  else
    {
      code[0] = (*nv_unfold) + '0';
      icode = 1;
    }
  code[icode++] = ' ';
  
  irep = 0;
  i = 0;
  inew = 1;

  /* first the outside vertex */

  while (representation[irep] != 0) {
    first[inew++] = 0;
    code[icode++] = i2a[representation[irep++]-1];
  }

  while (i<*nv_unfold)
    {
      if (representation[irep] == 0) 
	{
	  i++;
	  irep++;
	  if (i<*nv_unfold)
	    {
	      code[icode++] = ',';
	      code[icode++] = i2a[first[i]];
	    }
	}
      else 
	{
	  if (representation[irep] > MAX_V)
	    {
	      first[inew] = i;
	      representation[irep] = ++inew;
	    }
	  code[icode++] = i2a[representation[irep++]-1];
	}
    }
  code[icode] = 0;

}
