/* add a vertex, n, by placing it inside a face */

#include <triang.h>

void add_vertex(struct triang *t, int v1, int v2, int v3)
{
  int v, v4;

#if DEBUG
  if (v1 == v2 || v1 == v3 || v2 == v3) {
    printf("add_vertex: vertices (%d, %d and %d) must be distinct.\n",
	   v1,v2,v3);
    exit(0);
  }

  if (v1 < 0 || v1 >= t->nv || 
      v2 < 0 || v2 >= t->nv || 
      v3 < 0 || v3 >= t->nv) {
    printf("add_vertex: vertex (%d, %d or %d) out of range. must be betwee 0 and %.\n",
	   v1,v2,v3,t->nv);
    exit(0);
  }

  if (t->edge[v1][v2] != v3 && t->edge[v2][v1] != v3) {
    printf("add_vertex: (%d, %d, %d) not a face.\n",
	   v1,v2,v3);
    exit(0);
  }
#endif
  
  v4 = (t->nv)++;
  for (v=0;v<=v4;v++)
    t->edge[v][v4] = t->edge[v4][v] = -1;
  
  if (t->edge[v1][v2] == v3) {
    remove_face(t,v1,v2,v3);
    add_face(t,v1,v2,v4);
    add_face(t,v1,v4,v3);
    add_face(t,v2,v3,v4);
    }
  else {
    remove_face(t,v2,v1,v3);
    add_face(t,v2,v1,v4);
    add_face(t,v2,v4,v3);
    add_face(t,v1,v3,v4);
  }

  t->ne += 3;
}
