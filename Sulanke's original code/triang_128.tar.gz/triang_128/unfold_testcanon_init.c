/* calculate the canonical representation of an unfolded triangulaton */

#include <triang.h>

void unfold_testcanon_init(struct triang *t, int nv_unfold, 
			   int v_border[MAX_V], 
			   int r_border[MAX_V], int border_length, int dir,
			   int iborder, int label[MAX_V][MAX_V], 
			   int border[MAX_V][MAX_V],
			   int representation[], int mapping[], int colour[])
{

/* Tests whether starting from a given border edge (start at v_border[iborder]
   in direction dir) and constructing 
   the code so the r_border[iborder+(dir-1)/2] is opposite the outside vertex,
   an automorphism or even a better representation can
   be found. A better representation will be completely constructed and
   returned in "representation".  It works pretty similar to testcanon except
   for obviously necessary changes, so for extensive comments see testcanon */

  int number[MAX_V];
  int v1, v2, v3, v4;
  int last_number, actual_number;
  int startedge[MAX_V+1][3];
  int temp[3];
  int run, prev, vertex;
  int better;
  int crossings;
  int jborder;
  int lmapping[MAX_V];

  better = 0;
  for (v1 = 0; v1 < t->nv; v1++) number[v1] = 0;

  last_number = 1;
  lmapping[0] = -1;
  actual_number = 1;

  /* go around outside vertex */

  if (dir == +1)
    jborder = (iborder-1+border_length) % border_length;
  else
    jborder = (iborder+1) % border_length;
  while (last_number <= border_length) {
    v1 = v_border[jborder];
    if (dir == +1) {
      v3 = r_border[jborder];
      jborder = (jborder+1) % border_length;
    }
    else {
      jborder = (jborder-1+border_length) % border_length;
      v3 = r_border[jborder];
    }
    v2 = v_border[jborder];
      
    startedge[last_number][0] = v2;
    startedge[last_number][1] = opposite(t,v3,v1,v2);
    startedge[last_number][2] = v1;
    last_number++;
    lmapping[last_number-1] = v2;
    if (!number[v2])
      number[v2] = last_number;
    if (better)
      *representation = number[v2]; 
    else { 
      if (number[v2] > (*representation)) return;
      else if (number[v2] < (*representation))
	{ better = 1; *representation = number[v2]; }
    }
    representation++;
  }
  if ((*representation) != 0) { better = 1; *representation = 0; }
  representation++;

  /* go around real vertices */

  temp[0] = startedge[actual_number][0];  
  temp[1] = startedge[actual_number][1];  
  temp[2] = startedge[actual_number][2];  
  actual_number++;

  while (last_number < nv_unfold)
    {
      crossings = 0;
      for (run = temp[2], prev = temp[1]; 
	   (run != temp[1] && crossings == 0) || crossings == 1; )
	{
	  if (!number[run])
	    {
	      startedge[last_number][0] = run;
	      startedge[last_number][1] = temp[0];
	      startedge[last_number][2] = prev;
	      last_number++;
	      lmapping[last_number-1] = run;
	      number[run] = last_number;
	      vertex = colour[run];
	    }
	  else if (border[temp[0]][run]) 
	    if (crossings == 0)
	      vertex = ((actual_number-3+border_length)%border_length) + 2;
	    else
	      vertex = ((actual_number-1+border_length)%border_length) + 2;
	  else if (label[run][temp[0]] != -1)
	    vertex = (((label[run][temp[0]]-iborder)/dir+border_length) %
		      border_length) + 2;
	  else
	    vertex = number[run];

	  if (better)
	    *representation = vertex; 
	  else { 
	    if (vertex > (*representation)) return;
	    else if (vertex < (*representation))
	      { better = 1; *representation = vertex; }
	  }
	  representation++;

	  if (border[temp[0]][run])
	    crossings++;
	  if (crossings < 2) {
	    v4 = opposite(t,prev,temp[0],run);
	    prev = run;
	    run = v4;
	  }
	}

      if ((*representation) != 0) { better = 1; *representation = 0; }
      representation++;
      temp[0] = startedge[actual_number][0];  
      temp[1] = startedge[actual_number][1];  
      temp[2] = startedge[actual_number][2];  
      actual_number++;
    }
      
  while (actual_number <= nv_unfold)
    {
      crossings = 0;
      for (run = temp[2], prev = temp[1]; 
	   (run != temp[1] && crossings == 0) || crossings == 1; )
	{
	  if (border[temp[0]][run]) 
	    if (crossings == 0)
	      vertex = ((actual_number-3+border_length)%border_length) + 2;
	    else
	      vertex = ((actual_number-1+border_length)%border_length) + 2;
	  else if (label[run][temp[0]] != -1)
	    vertex = (((label[run][temp[0]]-iborder)/dir+border_length) %
		      border_length) + 2;
	  else
	    vertex = number[run];
	  if (better) *representation = vertex;
	  else
	    {
	      if (vertex > (*representation)) return;
	      if (vertex < (*representation))
		{ better = 1; *representation = vertex; }
	    }
	  representation++;

	  if (border[temp[0]][run])
	    crossings++;
	  if (crossings < 2) {
	    v4 = opposite(t,prev,temp[0],run);
	    prev = run;
	    run = v4;
	  }
	}
      
      if ((*representation) != 0) { better = 1; *representation = 0; }
      representation++;
      temp[0] = startedge[actual_number][0];  
      temp[1] = startedge[actual_number][1];  
      temp[2] = startedge[actual_number][2];  
      actual_number++;
    }
  
  if (better)
    for (v1 = 0; v1 < nv_unfold; v1++) 
      mapping[v1] = lmapping[v1];
    
  return;
}
