/* print the order neighbors of a triangulation in ascii form ala plantri */

#include <triang.h>

void print_ascii(struct triang *t)
{
  char text[MAX_CODE];

  encode_triang(t,text);
  printf("%s\n",text);
}
