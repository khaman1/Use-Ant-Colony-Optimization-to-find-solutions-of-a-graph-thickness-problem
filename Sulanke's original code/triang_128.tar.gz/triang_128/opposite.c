/* return the vertex opposite v1 through the edge (v2,v3) */

#include <stdio.h>
#include <triang.h>

int opposite(struct triang *t, int v1, int v2, int v3)
{
  /* return the vertex which is opposite v1 through the edge (v2,v3) */

  if (v1 == t->edge[v2][v3])
    return t->edge[v3][v2];
  else
    return t->edge[v2][v3];
}

