/* copy a triangulation */

#include <triang.h>

void copy_triang(struct triang *s, struct triang *t)
{
  
  int v1, v2;

  t->orient = s->orient;
  t->genus = s->genus;
  t->nv = s->nv;
  t->ne = s->ne;
  t->nf = s->nf;
  
  for (v1=0;v1<t->nv;v1++)
    for (v2=0;v2<t->nv;v2++)
      t->edge[v1][v2] = s->edge[v1][v2];

}
