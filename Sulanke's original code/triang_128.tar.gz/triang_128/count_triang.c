/* count the triangles in graph */

#include <triang.h>

int count_triang(struct triang *t)
{
  int v1,v2,v3;
  int count;

  count = 0;
  for (v1=0;v1<t->nv-2;v1++)
    for (v2=v1+1;v2<t->nv-1;v2++)
      if ((v3=t->edge[v1][v2]) > v2) {
	printf("triangle: %d %d %d\n",v1,v2,v3);
	count++;
      }
  return count;
}
