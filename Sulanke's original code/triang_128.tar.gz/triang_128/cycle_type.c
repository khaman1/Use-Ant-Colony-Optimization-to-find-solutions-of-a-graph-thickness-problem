/* 
   Routine to compute the cycle type of a cycle of a triangulation.
   The cycle is stored in the v[0],,v[n-1].  

   If the cycle is 2-sided 
   then we imagine that the triangulation is cut along the cycle
   and patched with two disks (new vertex adjacent to each vertex on cycle).  
   nv, ne, nf, genus, and orientation are computed for the resulting
   triangulation(s).

   If the cycle is 1-sided then we imagine that the 
   triangulation is cut along the cycle and patched with one disk.  
   nv, ne, nf, genus, and orientation are computed for this triangulation.

   If two triangulations result (cycle seperates the triangulation) then the 
   interior of the face (v[0],v[1],t.edge[v[0]][v[1]]) is assumed to be in the 
   first triangulation.

   Cycle types:
    0 if cycle is trivial (seperates the surface but is not essential).
    1 if cycle is 2-sided, seperates the surface, and is essential.
    2 if cycle is 2-sided nonseperating.
    3 if cycle is 1-sided (does not seperate the surface).
 */

/*

 */
#include <triang.h>



void visitit(struct triang *t, int border[MAX_V][MAX_V], 
	     int visited[MAX_V][MAX_V], int vseen[MAX_V],
	     int v1, int v2, int v3, int *oriented, int *nvisited, int *nvseen)
{
  /* recursive function to visit a face (v1,v2,v3) coming from the other side 
     of (v1,v2) which has already been visited */

  int v4;

  if (t->edge[v1][v2] == v3 && visited[v1][v2] != 0) {
    if (*oriented == 1)
      if (visited[v1][v2] == -1) *oriented = 0;
    return;}
  if (t->edge[v2][v1] == v3 && visited[v2][v1] != 0) {
    if (*oriented == 1)
      if (visited[v2][v1] == 1) *oriented = 0;
    return;}
  if (t->edge[v2][v3] == v1 && visited[v2][v3] != 0) {
    if (*oriented == 1)
      if (visited[v2][v3] == -1) *oriented = 0;
    return;}
  if (t->edge[v3][v2] == v1 && visited[v3][v2] != 0) {
    if (*oriented == 1)
      if (visited[v3][v2] == 1) *oriented = 0;
    return;}
  if (t->edge[v3][v1] == v2 && visited[v3][v1] != 0) {
    if (*oriented == 1)
      if (visited[v3][v1] == -1) *oriented = 0;
    return;}
  if (t->edge[v1][v3] == v2 && visited[v1][v3] != 0) {
    if (*oriented == 1)
      if (visited[v1][v3] == 1) *oriented = 0;
    return;}
  
  if (t->edge[v1][v2] == v3)
    visited[v1][v2] = 1;
  else if (t->edge[v2][v1] == v3) 
    visited[v2][v1] = -1;
  /*#if DEBUG*/
  else
    {
      printf("cycle_type: invalid v1, v2, v3 in visitit\n");
      exit(1);
    }
  /*#endif*/

  (*nvisited)++;

  if (!vseen[v3]) {
    (*nvseen)++;
    vseen[v3] = 1;
  }
  if (!border[v3][v2]) {
    v4 = opposite(t,v1,v3,v2);
    visitit(t,border,visited,vseen,v3,v2,v4,oriented,nvisited,nvseen);
  }
  if (!border[v1][v3]) {
    v4 = opposite(t,v2,v1,v3);
    visitit(t,border,visited,vseen,v1,v3,v4,oriented,nvisited,nvseen);
  }

}

void cycle_type(struct triang *t, int v[MAX_V], int n, int *type, 
		int genus[2], int orient[2], int nv[2], int ne[2], int nf[2])
{
  int i,j;         /* index of cycle vertices */
  int visited[MAX_V][MAX_V]; /* visited[i][j] is 1 if face (i,j,t->edge[i][j])
				has been visited coming across (i,j);
				visited[i][j] is -1 if face (i,j,t->edge[i][j])
				has been visited coming across (j,i);
				visited[i][j] is 0 if face (i,j,t->edge[i][j])
				has not been visited coming across (i,j) or 
				(j,i); */
  int border[MAX_V][MAX_V];  /* border[i][j] is 1 if edge (i,j) is on a 
				n-cycle */
  int vseen[MAX_V];   /* vseen[i] is 1 if i is on border or in the interior of
			 new surface */
  int nvisited;       /* number of faces that have been visited */
  int oriented;       /* is new surface orientable? */
  int nvseen;         /* number of vertices on border or in the interior of
			 new surface */
  int v4, v5, v6;
  int two_sided;
  
  /*#if DEBUG*/
  if (n < 3 || n > t->nv) {
    printf("cycle_type: length of cycle, n (%d) must be 3..%d.\n",
	   n,t->nv);
    exit(0);
  }
  for (i=0;i<n;i++) 
    if (v[i] < 0 || v[i] >= t->nv) {
      printf("cycle_type: %d-th cycle vertex (%d) must be 0..%d.\n",
	     i,v[i],t->nv-1);
      exit(0);
    }
  for (i=0;i<n-1;i++)
    for (j=i+1;j<n;j++)
      if (v[i] == v[j]) {
	printf("cycle_type: %d-th and %d-th cycle vertices are the same (%d).\n",
	       i,j,v[i]);
	exit(0);
      }
  for (i=0;i<n-1;i++)
    if (t->edge[v[i]][v[(i+1)%n]] == -1) {
      printf("cycle_type: %d-th edge of cycle (%d, %d) not an edge .\n",
	     i,v[i],v[(i+1)%n]);
      exit(0);
    }
  
  /*#endif*/
 
  /* check if 1-sided or 2-sided */

  v6 = t->edge[v[0]][v[1]];

  for (i=0;i<n;i++) {
    v4 = v6;
    v6 = v[i];
    while (v4 != v[(i+2)%n]) {
      v5 = opposite(t,v6,v[(i+1)%n],v4);
      v6 = v4;
      v4 = v5;
    }
  }

  two_sided = (v6 == t->edge[v[0]][v[1]]);

  /* visit the faces of the first triangulation */

  for (i=0;i<t->nv;i++) {
    for (j=0;j<t->nv;j++)
      visited[i][j] = border[i][j] = 0;
    vseen[i] = 0;
  }
  nvisited = 0;
  oriented = 1;
  nvseen = n;
  
  for (i=0;i<n;i++) {
    border[v[i]][v[(i+1)%n]] = border[v[(i+1)%n]][v[i]] = 1;
    vseen[v[i]] = 1;
  }
  
  visitit(t,border,visited,vseen,v[0],v[1],t->edge[v[0]][v[1]],&oriented,
	  &nvisited,&nvseen);

  if (!two_sided)
    *type = 3;
  else if (nvisited == t->nf)
    *type = 2;
  else
    *type = 1;    /* may be 0 */

  /* do the math for first (or only) new surface */
  
  if (*type == 1) {
    nv[0] = nvseen + 1;
    nf[0] = nvisited + n;
  }
  else if (*type == 2) {
    nv[0] = nvseen + n + 2;
    nf[0] = nvisited + n + n;
  }
  else {
    nv[0] = nvseen + n + 1;
    nf[0] = nvisited + n + n;
  }
  ne[0] = (3*nf[0])/2;
  genus[0] = 2 - nv[0] + ne[0] - nf[0];
  orient[0] = oriented;
  
  /* do the math for other new surface, if any */
  
  if (*type >= 2)
    /* cycle does not seperate triangulation */
    nv[1] = ne[1] = nf[1] = orient[1] = genus[1] = -1;
  else {
    nv[1] = t->nv - nvseen + n + 1;
    nf[1] = t->nf - nvisited + n;
    ne[1] = (3*nf[1])/2;
    genus[1] = 2 - nv[1] + ne[1] - nf[1];
    if (oriented)
      orient[1] = t->orient;
    else {
      if (genus[1] == 0)
	orient[1] = 1;
      else if (genus[1]%2 == 1)
	orient[1] = 0;
      else
	orient[1] = -1;
    }
    if (genus[0] == 0 || genus[1] == 0)
      *type = 0;
  }

  /* if type is 1 and the orientation of second triangulation is unknown 
     repeat search in second triangulation */

  if (*type == 1 && orient[1] == -1) {
    for (i=0;i<t->nv;i++) {
      for (j=0;j<t->nv;j++)
	visited[i][j] = border[i][j] = 0;
      vseen[i] = 0;
    }
    nvisited = 0;
    oriented = 1;
    nvseen = n;
    
    for (i=0;i<n;i++) {
      border[v[i]][v[(i+1)%n]] = border[v[(i+1)%n]][v[i]] = 1;
      vseen[v[i]] = 1;
    }
    
    visitit(t,border,visited,vseen,v[1],v[0],t->edge[v[1]][v[0]],&oriented,
	    &nvisited,&nvseen);
    
    orient[1] = oriented;
  }
}
