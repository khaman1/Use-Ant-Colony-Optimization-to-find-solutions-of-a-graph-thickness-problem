/* check if traingulation has a near triangulation as a spanning subgraph */

#include <triang.h>

void debuger(int call,int vfirst,int vlast,int idebug,int v1,int v2,int v3)
{
  int i;

  printf("%2d %2d %2d",call,vfirst,vlast);
  for (i=0;i<idebug;i++)
    printf("         ");

  printf("%2d %2d %2d\n",v1,v2,v3);
}


int
near_triang1(int idebug, struct triang *t, int ntri[], int next[], int in[], int nused, 
	     int vfirst, int vlast)
{
  int v0,v1,v2,v3;   /* vertices */
  int save;

  v0 = -1;
  v1 = vfirst;
  do
    {
      v2 = next[v1];
      v3 = t->edge[v1][v2];
      if (v3 == in[v1])
	v3 = t->edge[v2][v1];
      if (ntri[v3] > 0) {
	if (next[v2] == v3) {
	  next[v1] = v3;
	  save = in[v1];
	  in[v1] = v2;
	  if (v1 == vlast || v2 == vlast) {
	    if (v0 == -1) 
	      for (v0 = next[v1]; next[v0] != v1; v0 = next[v0]) {}
	    //	    debuger(1,v0,v1,idebug,v1,v2,v3);
	    if (near_triang1(idebug+1,t,ntri,next,in,nused,v0,v1))
	      return 1;
	  }
	  else {
	    //debuger(2,v1,vlast,idebug,v1,v2,v3);
	    if (near_triang1(idebug+1,t,ntri,next,in,nused,v1,vlast))
	      return 1;
	  }
	  next[v1] = v2;
	  in[v1] = save;
	}
      }
    
      else /* ntri[v3] == 0 */ {
	next[v1] = v3;
	save = in[v1];
	in[v1] = v2;
	next[v3] = v2;
	in[v3] = v1;
	ntri[v3] = 1;
	nused++;
	if (nused == t->nv)
	  return 1;
	if (v1 == vlast) {
	  //debuger(3,v1,v3,idebug,v1,v2,v3);
	  if (near_triang1(idebug+1,t,ntri,next,in,nused,v1,v3))
	    return 1;
	}
	else {
	  //debuger(4,v1,vlast,idebug,v1,v2,v3);
	  if (near_triang1(idebug+1,t,ntri,next,in,nused,v1,vlast))
	    return 1;
	}
	nused--;
	ntri[v3] = 0;
	next[v1] = v2;
	in[v1] = save;
      }
      v0 = v1;
      v1 = next[v1];
    } while (v1 != next[vlast]);
  
  return 0;
}

int
near_triang(struct triang *t)
{
  int i,v1,v2,v3;   /* vertices */
  int nused;        /* number of vertices in current near triangulation */
  int next[MAX_V];  /* if i is on boundary then next[i] is next vertex on 
		       boundary */
  int in[MAX_V];    /* if i is on boundary then in[i] is the interior vertex 
		       on the triangle with boundary edge (i,next[i]) */
  int ntri[MAX_V];  /* ntri[i] = number of interior triangles of current near 
		       triangulation containing i */
  int vfirst;

  for (i=0; i<t->nv; i++) {
    ntri[i] = 0;
  }
  
  v1 = 0;
  for (vfirst = 1; t->edge[v1][vfirst] == -1; vfirst++) {}
  v2 = vfirst;
  v3 = t->edge[v1][v2];
  do
    {
      ntri[v1] = ntri[v2] = ntri[v3] = 1;
      nused = 3;
      next[v1] = v2;
      in[v1] = v3;  
      next[v2] = v3;
      in[v2] = v1;
      next[v3] = v1;
      in[v3] = v2;
      if (v2 == vfirst) {
	//debuger(5,v1,v3,0,v1,v2,v3);
	if (near_triang1(1,t,ntri,next,in,nused,v1,v3))
	  return 1;
      }
      else {
	//debuger(6,v2,v3,0,v1,v2,v3);
	if (near_triang1(1,t,ntri,next,in,nused,v2,v3))
	  return 1;
      }
      ntri[v1] = ntri[v2] = ntri[v3] = 0;
      
      if (t->edge[v1][v3] == v2) {
	v2 = v3;
	v3 = t->edge[v2][v1];
      }
      else {
	v2 = v3;
	v3 = t->edge[v1][v2];
      }
    } while (v2 != vfirst);
  
  fprintf(stderr," near triangulation not found\n");
  return 0;
  
}

