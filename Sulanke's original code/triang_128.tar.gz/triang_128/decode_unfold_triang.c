/* create a triangulation and border from an encoded unfolded triangulation */

#include <stdio.h>
#include <triang.h>

int decode_unfold_triang(char *text, struct triang *t, int border[MAX_V][MAX_V])

/* assume the vertices around a are in order bcde... */

{
  int itext, v0, v1, v2, v3, nv, nv_unfold;
  int m0, m1, m2, m3;
  int anei;           /* neighbor of a, border vertex */
  int map[MAX_V];     /* for vertex i in unfolded triangulation, map[i] is 
			 vertex number in t */
  int nborder;        /* number of t vertices on border */
  int border_length;  
  int iborder;        /* border vertex index */

  /* read the number of vertices */

  sscanf(text,"%d ",&nv_unfold);
  if (nv_unfold < 4 || nv_unfold > MAX_V) {
    printf("decode_unfold_triang: bad format or nv out of range\n %s\n",text);
    return 0;
  }

  /* preread neighbors of a */

  for (v1=0; v1<nv_unfold; v1++)
    map[v1] = -1;

  if (nv_unfold < 10)
    itext = 2;
  else
    itext = 3;

  nborder = 0;
  border_length = 0;
  while (text[itext] != ',') {
    anei = text[itext++] - 'a';
    border_length++;
    if (anei == border_length) {
      nborder++;
      map[border_length] = anei-1 + nborder - border_length;
    }
    else {
      map[border_length] = map[anei];
    }
  }
  itext++;
  nv = nv_unfold + nborder - border_length - 1;
  for (v1=0;v1<nv-nborder;v1++)
    map[border_length+1+v1] = nborder + v1;

  for (v1=0; v1<nv; v1++)
    for (v2=0; v2<nv; v2++)
      border[v1][v2] = 0;
  for (iborder=0; iborder<border_length; iborder++)
    if (iborder == 0)
      border[map[border_length]][map[1]] = 
	border[map[1]][map[border_length]] = 1;
    else
      border[map[iborder]][map[iborder+1]] = 
	border[map[iborder+1]][map[iborder]] = 1;
  
  clear_triang(t,nv);
  t->orient = 1;
  t->nv = nv;
  v1 = 1;

  while (v1 < nv_unfold) {
    m1 = map[v1];
    v0 = text[itext++] - 'a';
    m0 = map[v0];
    if (v0 == 0) {
      /* skip outside face */
      v2 = text[itext++] - 'a';
      m2 = map[v2];
    }
    else
      m2 = m0;

    while (text[itext] != ',' && text[itext] != 10 && text[itext] != 0) {
      v3 = text[itext++] - 'a';
      m3 = map[v3];
      if (t->edge[m1][m2] == m3) {
	/* do nothing */
      }
      else if (t->edge[m2][m1] == m3) {
	t->orient = 0;
      }
      else if (t->edge[m1][m2] == -1 &&
	       t->edge[m2][m3] == -1 &&
	       t->edge[m3][m1] == -1) {
	add_face(t,m1,m2,m3);
      }
      else {
	t->orient = 0;
	add_face(t,m1,m2,m3);
      }
      m2 = m3;
    }
    if (v0 != 0) {
      m3 = m0;
      if (t->edge[m1][m2] == m3) {
	/* do nothing */
      }
      else if (t->edge[m2][m1] == m3) {
	t->orient = 0;
      }
      else if (t->edge[m1][m2] == -1 &&
	       t->edge[m2][m3] == -1 &&
	       t->edge[m3][m1] == -1) {
	add_face(t,m1,m2,m3);
      }
      else {
	t->orient = 0;
	add_face(t,m1,m2,m3);
      }
    }
    v1++;
    itext++;
  }
  
  t->ne = (3*t->nf)/2;
  if (t->orient == 1)
    t->genus = (2 - (t->nv - t->ne + t->nf))/2;
  else
    t->genus =  2 - (t->nv - t->ne + t->nf);
  
  return 1;
}
