/* create a triangulation using plantri format input */

#include <stdio.h>
#include <triang.h>

int decode_triang(char *text, struct triang *t)
{
  int itext, v0, v1, v2, v3, nv;

  /* read the number of vertices */

  sscanf(text,"%d ",&nv);
  if (nv < 4 || nv > MAX_V) {
    printf("read_triang: bad format or nv out of range\n %s\n",text);
    return 0;
  }

  clear_triang(t,nv);
  t->orient = 1;
  t->nv = nv;
  v1 = 0;
  if (nv < 10)
    itext = 2;
  else
    itext = 3;
  
  while (v1 < nv) {
    v0 = v2 = a2i[text[itext++]];
    if (v0<0 || v0>nv-1) {
      printf("decode_triang1: vertex (%c) not between a and %c.\n",
	     text[itext-1],i2a[nv-1]);
      return 0;
    }
    while (text[itext] != ',' && text[itext] != 10 && text[itext] != 0) {
      v3 = a2i[text[itext++]];
      if (v3<0 || v0>nv-1) {
	printf("decode_triang2: vertex (%c) not between a and %c.\n",
	       text[itext-1],i2a[nv-1]);
	return 0;
      }
      if (t->edge[v1][v2] == v3) {
	/* do nothing */
      }
      else if (t->edge[v2][v1] == v3) {
	t->orient = 0;
      }
      else if (t->edge[v1][v2] == -1 &&
	       t->edge[v2][v3] == -1 &&
	       t->edge[v3][v1] == -1) {
	add_face(t,v1,v2,v3);
      }
      else {
	t->orient = 0;
	add_face(t,v1,v2,v3);
      }
      v2 = v3;
    }
    v3 = v0;
    if (t->edge[v1][v2] == v3) {
      /* do nothing */
    }
    else if (t->edge[v2][v1] == v3) {
      t->orient = 0;
    }
    else if (t->edge[v1][v2] == -1 &&
	     t->edge[v2][v3] == -1 &&
	     t->edge[v3][v1] == -1) {
      add_face(t,v1,v2,v3);
    }
    else {
      t->orient = 0;
      add_face(t,v1,v2,v3);
    }
    v1++;
    itext++;
  }
  
  t->ne = (3*t->nf)/2;
  if (t->orient == 1)
    t->genus = (2 - (t->nv - t->ne + t->nf))/2;
  else
    t->genus =  2 - (t->nv - t->ne + t->nf);
  
  return 1;
}
