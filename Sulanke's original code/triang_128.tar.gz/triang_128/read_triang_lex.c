/* creat a triangulation using lex format input */

#include <stdio.h>
#include <triang.h>
#define LINELEN 2000

int read_triang_lex(struct triang *t)
{
  char text[LINELEN];

  /* read the lex representation of the triangulation */
  /* return 0 if eof */

  if (fgets(text,LINELEN,stdin) == NULL) {
    return 0;
  }

  return decode_triang_lex(text,t);
}
