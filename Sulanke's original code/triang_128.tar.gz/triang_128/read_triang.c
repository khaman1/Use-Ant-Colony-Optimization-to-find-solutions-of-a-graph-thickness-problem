/* creat a triangulation using plantri format input */

#include <stdio.h>
#include <triang.h>

int read_triang(struct triang *t)
{
  char text[MAX_CODE];

  /* read the ascii representation of the triangulation */
  /* return 0 if eof */

  if (fgets(text,MAX_CODE,stdin) == NULL) {
    return 0;
  }

  return decode_triang(text,t);
}
