/* calculate the canonical representation of a triangulaton */

#include <triang.h>

void canon(struct triang *t, char code[], int mapping[])
{
/* A possible starting edge for the construction of a representation is 
   one with lexicographically maximal colour triple (start,end,right).

   mapping[i] is the vertex in t corresponding to the i-th character.
   
*/

  int i, j, max_vertex;
  int maxstart, maxend, maxright; /* (maxstart,maxend,maxright) will be the 
				     chosen colour triple of an edge */
  int startlist[2*MAX_V*MAX_V][3];
  int list_length;
  int colour[MAX_V];    /* degree + MAX_V */
  int representation[MAX_V*MAX_V];
  int icode, inew, irep;
  int first[MAX_V];

  for (i=0; i<t->nv; i++)
    colour[i] = MAX_V;
  for (i=0; i<t->nv-1; i++)
    for (j=i+1; j<t->nv; j++)
      if (t->edge[i][j] >= 0)
	{
	  colour[i]++;
	  colour[j]++;
	}
  
  /* find largest possible start for an edge */
  
  maxstart = colour[0];
  max_vertex = 0;
  for (i=1; i<t->nv; i++)
    if (colour[i] > maxstart) {
      maxstart = colour[i];
      max_vertex = i;
    }
  
  /* determine the largest possible end for a vertex with colour maxstart 
     and determine a list of all edges with this colour pair.*/

  maxend = 0;
  maxright = 0;
  list_length = 0;

  for (i=max_vertex; i<t->nv; i++) 
    if (colour[i] == maxstart)
      for (j=0; j<t->nv; j++)
	if (t->edge[i][j] >= 0)
	  {
	    if (colour[j] > maxend || 
		(colour[j] == maxend &&
		 (colour[t->edge[i][j]] > maxright)))
	      { 
		list_length = 0;
		startlist[list_length][0] = i;
		startlist[list_length][1] = j;
		startlist[list_length][2] = t->edge[i][j];
		list_length++; 
		maxend = colour[j];
		maxright = colour[t->edge[i][j]];
	      }
	    else 
	      if (colour[j] == maxend &&
		  colour[t->edge[i][j]] == maxright)
		{ 
		  startlist[list_length][0] = i;
		  startlist[list_length][1] = j;
		  startlist[list_length][2] = t->edge[i][j];
		  list_length++;
		}
	    if (colour[j] > maxend || 
		(colour[j] == maxend &&
		 (colour[t->edge[j][i]] > maxright)))
	      { 
		list_length = 0;
		startlist[list_length][0] = i;
		startlist[list_length][1] = j;
		startlist[list_length][2] = t->edge[j][i];
		list_length++; 
		maxend = colour[j];
		maxright = colour[t->edge[j][i]];
	      }
	    else 
	      if (colour[j] == maxend &&
		  colour[t->edge[j][i]] == maxright)
		{ 
		  startlist[list_length][0] = i;
		  startlist[list_length][1] = j;
		  startlist[list_length][2] = t->edge[j][i];
		  list_length++;
		}
	  }
  
  /* OK -- so there is no larger triple and now we have to determine the 
     smallest representation */
  
  testcanon_first_init(t, startlist[0], representation, mapping, colour);
  
  for (i = 1; i < list_length; i++)
    testcanon_init(t, startlist[i], representation, mapping, colour);

  /* create code */
  
  if (t->nv >= 10) 
    {
      code[0] = (t->nv / 10) + '0';
      code[1] = (t->nv % 10) + '0';
      icode = 2;
    }
  else
    {
      code[0] = (t->nv) + '0';
      icode = 1;
    }
  code[icode++] = ' ';
  code[icode++] = 'b';

  irep = 0;
  i = 0;
  inew = 2;
  first[1] = 0;
  first[2] = 0;
  while (i<t->nv)
    {
      if (representation[irep] == 0) 
	{
	  i++;
	  irep++;
	  if (i<t->nv)
	    {
	      code[icode++] = ',';
	      code[icode++] = first[i] + 'a';
	    }
	}
      else 
	{
	  if (representation[irep] > MAX_V)
	    {
	      first[inew] = i;
	      representation[irep] = ++inew;
	    }
	  code[icode++] = representation[irep++] + 'a' - 1;
	}
    }
  code[icode] = 0;
}
