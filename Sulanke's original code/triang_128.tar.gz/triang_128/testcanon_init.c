/* calculate the canonical representation of a triangulaton */

#include <triang.h>

void testcanon_init(struct triang *t, int givenedge[3], 
		    int representation[], int mapping[], int colour[])
{

/* Tests whether starting from a given edge and constructing the code in
   "->next" direction, an automorphism or even a better representation can
   be found. A better representation will be completely constructed and
   returned in "representation".  It works pretty similar to testcanon except
   for obviously necessary changes, so for extensive comments see testcanon */

  int number[MAX_V], i;
  int last_number, actual_number;
  int startedge[MAX_V+1][3];
  int temp[3];
  int run, prev, vertex;
  int better;

  better = 0;
  for (i = 0; i < t->nv; i++) number[i] = 0;
  
  number[givenedge[0]] = 1;
  number[givenedge[1]] = 2;
  last_number = 2;
  startedge[1][0] = givenedge[1];
  startedge[1][1] = givenedge[0];
  startedge[1][2] = givenedge[2];

  actual_number = 1;
  temp[0] = givenedge[0];
  temp[1] = givenedge[1];
  temp[2] = t->edge[givenedge[0]][givenedge[1]];
  if (temp[2] == givenedge[2])
    temp[2] = t->edge[givenedge[1]][givenedge[0]];

  while (last_number < t->nv)
    {
      for (run = temp[2], prev = temp[1]; run != temp[1]; )
	{
	  vertex = run;
	  if (!number[vertex])
	    {
	      startedge[last_number][0] = run;
	      startedge[last_number][1] = temp[0];
	      startedge[last_number][2] = prev;
	      last_number++; 
	      number[vertex] = last_number;
	      vertex = colour[vertex];
	    }
	  else
	    vertex = number[vertex];

	  if (better)
	    *representation = vertex; 
	  else { 
	    if (vertex > (*representation)) return;
	    else if (vertex < (*representation))
	      { better = 1; *representation = vertex; }
	  }
	  representation++;

	  if (t->edge[temp[0]][run] != prev)
	    {
	      prev = run;
	      run = t->edge[temp[0]][run];
	    }
	  else
	    {
	      prev = run;
	      run = t->edge[run][temp[0]];
	    }
	}

      if ((*representation) != 0) { better = 1; *representation = 0; }
      representation++;
      temp[0] = startedge[actual_number][0];  
      temp[1] = startedge[actual_number][1];  
      temp[2] = startedge[actual_number][2];  
      actual_number++;
    }
      
  while (actual_number <= t->nv)
    {
      for (run = temp[2], prev = temp[1]; run != temp[1]; )
	{
	  vertex = number[run];
	  if (better) *representation = vertex;
	  else
	    {
	      if (vertex > (*representation)) return;
	      if (vertex < (*representation))
		{ better = 1; *representation = vertex; }
	    }
	  representation++;

	  if (t->edge[temp[0]][run] != prev)
	    {
	      prev = run;
	      run = t->edge[temp[0]][run];
	    }
	  else
	    {
	      prev = run;
	      run = t->edge[run][temp[0]];
	    }
	}
      
      if ((*representation) != 0) { better = 1; *representation = 0; }
      representation++;
      temp[0] = startedge[actual_number][0];  
      temp[1] = startedge[actual_number][1];  
      temp[2] = startedge[actual_number][2];  
      actual_number++;
    }
  
  if (better)
    for (i = 0; i < t->nv; i++) 
      mapping[number[i]-1] = i;
    
  return;
}
