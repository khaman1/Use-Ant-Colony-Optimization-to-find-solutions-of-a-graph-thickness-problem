/* encode the order neighbors of a triangulation in PLANAR_CODE ala plantri */

#include <triang.h>

void encode_planar_code(struct triang *t, char code[])
{
  int v1,v2;
  int first,prev,next;
  int ic;

#if DEBUG
  if (t->nv < 4 || t->nv > MAX_V)
    {
      printf("encode_planar_code: number of vertices must be at least 4 and less than %d but is %d.\n",MAX_V,t->nv);
      exit(0);
    }
#endif

  ic = 0;
  code[ic++] = t->nv;

  for (v1=0;v1<t->nv;v1++) {
    for (v2 = 0; (v2 == v1 || t->edge[v1][v2] == -1) && v2 < t->nv; v2++) {}
    if (v2 < t->nv) {
      first = v2;
      if (t->orient || t->edge[v1][v2] < t->edge[v2][v1])
	next = t->edge[v1][v2];
      else
	next = t->edge[v2][v1];
      code[ic++] = v2+1;
      while (next != first) {
	prev = v2;
	v2 = next;
	code[ic++] = v2+1;
	if (t->edge[v1][v2] != prev)
	  next = t->edge[v1][v2];
	else
	  next = t->edge[v2][v1];
      }
    }
    code[ic++] = 0;
  }
}
