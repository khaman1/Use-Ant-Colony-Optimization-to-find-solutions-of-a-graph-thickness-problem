/* print adjacency matrix */

#include <triang.h>

void print_adj(int nt[MAX_V][MAX_V],int nv)
{
  int v1,v2;

  if (nv>100) {
    printf("\n    ");
    for (v2=0;v2<nv;v2++)
      printf("%1d",v2/100);
  }
  printf("\n    ");
  for (v2=0;v2<nv;v2++)
    printf("%1d",(v2/10)%10);
  printf("\n    ");
  for (v2=0;v2<nv;v2++)
    printf("%1d",v2%10);
  printf("\n");
  
  for (v1=0;v1<nv;v1++) {
    printf("\n%3d ",v1);
    for (v2=0;v2<nv;v2++)
      printf("%1d",nt[v1][v2]);
  }
  printf("\n\n");

}




