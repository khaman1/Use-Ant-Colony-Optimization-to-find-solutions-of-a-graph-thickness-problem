/* calculate the canonical representation of an unfolded triangulaton */

#include <triang.h>

void unfold_canon(struct triang *t, int border[MAX_V][MAX_V], 
		  int *nv_unfold, char code[], int mapping[])
{
/* 
   The first vertex (a) is the outside vertex.  The next vertex (b) is one of 
   the vertices which occurs the most on the border (the corner, if there is 
   one).  The third vertex (c) is chosen to lexically minimize the code around 
   a.  The labels around a would normally be bcdefg... but we use the smallest
   identified label.
   nv_unfold is the number of vertices in the unfolded triangulation including
   the outside vertex.
   mapping[i] is the vertex in t corresponding to the i-th character.
*/

  int v1, v2, v3, v4;
  int colour[MAX_V];    /* degree + MAX_V */
  int representation[MAX_V*MAX_V];
  int i, icode, inew, irep;
  int first[MAX_V];
  int border_count[MAX_V]; /* number of times vertex appears on border */
  int max_border_count;    /* maximum number of times vertex appears on 
			      border */
  int v_max_border_count;  /* vertex with max_border_count */
  int v_nei_max_border_count; /* border neighbor of v_max_border_count */
  int dups;                /* number of duplicate vertices on border */
  int border_length;       /* length of border */
  int v_border[MAX_V];     /* v_border[i] is the ith vertex as we go around the
			      border. */
  int r_border[MAX_V];     /* r_border[i] is the third vertex of the face to 
			      the right of (v_border[i],v_border[i+1]) */
  int border1, border2;    /* any edge on border */
  int iborder;             /* border vertex index */
  int label[MAX_V][MAX_V]; /* label[i][j] = border index assigned to vertex 
                              i for edge between i and j */
  
  /* colour[i] = MAX_V + degree[i] */
  /* count number of times a vertex occurs on the border */
  
  for (v1=0; v1<t->nv; v1++) {
    colour[v1] = MAX_V;
    border_count[v1] = 0;
    for (v2 = 0; v2 < t->nv; v2++)
      label[v1][v2] = -1;
  }
  dups = 0;
  border_length = 0;
  for (v1=0; v1<t->nv; v1++) {
    for (v2=v1+1; v2<t->nv; v2++)
      if (t->edge[v1][v2] >= 0)
	{
	  colour[v1]++;
	  colour[v2]++;
	  if (border[v1][v2]) {
	    border_count[v1]++;
	    border_count[v2]++;
	    border1 = v1;
	    border2 = v2;
	    border_length += 2;
	  }
	}
    if (border_count[v1] > 0)
      dups = dups + border_count[v1] - 1;
  }

  *nv_unfold = t->nv + dups + 1;

  /* go around the border */

  v1 = border1;
  v2 = border2;
  v3 = t->edge[v1][v2];

  max_border_count = 0;
  for (iborder=0; iborder<border_length; iborder++) {
    if (border_count[v1] > max_border_count) {
      max_border_count = border_count[v1];
      v_max_border_count = v1;
    }
    v_border[iborder] = v1;
    r_border[iborder] = v3;

    while (!border[v2][v3]) {
      label[v2][v3] = (iborder+1)%border_length;
      v4 = v1;
      v1 = v3;
      v3 = opposite(t,v4,v2,v1);
    }
    v4 = v3;
    v3 = v1;
    v1 = v2;
    v2 = v4;
  }

  /* set representation so that first call will be considered an improvement */
  
  representation[0] = MAX_V + MAX_V;
  
  for (iborder=0; iborder<border_length; iborder++)
    if (border_count[v_border[iborder]] == max_border_count) {
      unfold_testcanon_init(t, *nv_unfold, v_border, r_border, border_length,
			    +1, iborder,
			    label, border, representation, mapping, colour);
      unfold_testcanon_init(t, *nv_unfold, v_border, r_border, border_length, 
			    -1, iborder,
			    label, border, representation, mapping, colour);
    }
  
  /* create code */
  
  if (*nv_unfold >= 10) 
    {
      code[0] = ((*nv_unfold) / 10) + '0';
      code[1] = ((*nv_unfold) % 10) + '0';
      icode = 2;
    }
  else
    {
      code[0] = (*nv_unfold) + '0';
      icode = 1;
    }
  code[icode++] = ' ';
  
  irep = 0;
  i = 0;
  inew = 1;

  /* first the outside vertex */

  while (representation[irep] != 0) {
    first[inew++] = 0;
    code[icode++] = representation[irep++] + 'a' - 1;
  }

  while (i<*nv_unfold)
    {
      if (representation[irep] == 0) 
	{
	  i++;
	  irep++;
	  if (i<*nv_unfold)
	    {
	      code[icode++] = ',';
	      code[icode++] = first[i] + 'a';
	    }
	}
      else 
	{
	  if (representation[irep] > MAX_V)
	    {
	      first[inew] = i;
	      representation[irep] = ++inew;
	    }
	  code[icode++] = representation[irep++] + 'a' - 1;
	}
    }
  code[icode] = 0;
}
