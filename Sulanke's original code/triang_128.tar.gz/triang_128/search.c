/* Program to search for two triangulations whose union's complement is triangle 
   free. */

#include <triang.h>

main()
     
{
  struct triang t[2];    /* the two triangulations */
  struct triang c;         /* the complement of their union */
  int nv;
  int v1,v2,v3,v4,v;
  int total_count,count[MAX_V][MAX_V],actual_count;
  int ran;
  int it;
  int ok;
  int nflips;
  int delta_tri;
  int trys;

  nv = 19;

  total_count = 100;
  while (total_count > 0) {

    /* create the triangulations and the complement */

    create_triang(&t[0],nv);
    create_triang(&t[1],nv);
    scramble_triang(&t[1]);
    ran_flip_triang(&t[0],500);
    ran_flip_triang(&t[1],500);
    c.nv = nv;
    clear_triang(&c);
    
    for (v1=0;v1<nv-1;v1++)
      for (v2=v1+1;v2<nv;v2++)
	if (!t[0].edge[v1][v2] && !t[1].edge[v1][v2])
	  add_edge(&c,v1,v2);
    
    /* for each pair of vertices of c, count the number of common neighbors 
       (potential triangles) */
    
    total_count = 0;
    for (v1=0;v1<nv-1;v1++)
      for (v2=v1+1;v2<nv;v2++) {
	count[v1][v2] = 0;
	for (v3=0;v3<nv;v3++)
	  if (c.edge[v1][v3] && c.edge[v2][v3])
	    count[v1][v2]++;
	count[v2][v1] = count[v1][v2];
	if (c.edge[v1][v2])
	  total_count = total_count + count[v1][v2];
      }
    total_count = total_count/3;
    
    /* repeat until we have found the solution, ha! */
    
    trys = 0;
    nflips = 0;
    while (total_count > 0 && trys<1000) {
      
      /* pick a random edge */
      
      ok = 0;
      
      while (!ok && trys<1000) {
	it = rand() & 01;
	v1 = rand() % nv;
	v2 = rand() % nv;
	
	/* if it is really an edge and can be flipped, flip it. */
	
	/* if it is really an edge ... */
	
	if (t[it].edge[v1][v2]) {
	  
	  /* ... and can be flipped, ... */
	  
	  ok = find_flip(&t[it],v1,v2,&v3,&v4);
	  if (ok) {
	    
	    /* ... and number of triangles in complement does not increase ... */
	    
	    delta_tri = 0;
	    if (!t[1-it].edge[v1][v2]) {
	      delta_tri = delta_tri + count[v1][v2];
	    }
	    if (!t[1-it].edge[v3][v4]) {
	      delta_tri = delta_tri - count[v3][v4];
	    }
	    
	    trys++;
	    if (delta_tri < 0) trys = 0;
	    
	    if (delta_tri <= 0) {
	      
	      /* ... flip it. */
	      
	      nflips++;
	      flip_edge(&t[it],v1,v2,v3,v4);
	    }
	    else
	      ok = 0;
	  }
	}
      }
      
      if (ok) {
	
	/* update the counts */
	
	if (!t[1-it].edge[v1][v2]) {
	  add_edge(&c,v1,v2);
	  total_count = total_count + count[v1][v2];
	  for (v=0;v<nv;v++)
	    if (c.edge[v][v1])
	      count[v][v2] = ++count[v2][v];
	  for (v=0;v<nv;v++)
	    if (c.edge[v][v2])
	      count[v][v1] = ++count[v1][v];
	}
	
	if (!t[1-it].edge[v3][v4]) {
	  remove_edge(&c,v3,v4);
	  total_count = total_count - count[v3][v4];
	  for (v=0;v<nv;v++)
	    if (c.edge[v][v3])
	      count[v][v4] = --count[v4][v];
	  for (v=0;v<nv;v++)
	    if (c.edge[v][v4])
	      count[v][v3] = --count[v3][v];
	}
	
	/*
	printf("number of flips = %d\n",nflips);
	printf("number of triangles = %d\n",total_count);
	printf("number of edges = %d\n",c.ne);
	printf("\n");
	*/
      }
    }
    if (total_count < 10) printf("number of triangles = %d\n",total_count);
  }

  /* dump */

  printf("first triangulation\n");
  print_triang(&t[0]);
  printf("second triangulation\n");
  print_triang(&t[1]);
  printf("complement\n");
  print_triang(&c);
  printf("number of triangles = %d\n",total_count);

}
