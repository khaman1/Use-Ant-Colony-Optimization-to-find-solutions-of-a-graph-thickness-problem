/* determine if an edge can be contracted without producing multiple edges  */

#include <triang.h>

int can_contract(struct triang *t, int v1, int v2, int *o1, int *o2)
{
  int v;

  /* find the other two corners */

#if DEBUG
  if (t->edge[v1][v2] == -1 || t->edge[v2][v1] == -1) {
    printf("can_contract: corrupted faces at edge (%d,%d)\n",v1,v2);
    exit(0);
  }
#endif

  *o1 = t->edge[v1][v2];
  *o2 = t->edge[v2][v1];
  
  for (v=0; v<t->nv; v++)
    if (v != v1 &&
	v != v2 &&
	v != *o1 &&
	v != *o2 &&
	t->edge[v1][v] != -1 &&
	t->edge[v2][v] != -1)
      return 0;
  
  return 1;
}
